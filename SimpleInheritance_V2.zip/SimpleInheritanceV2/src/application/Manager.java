package application;

public class  Manager extends Employee {

	private double _bonus;

	public Manager(String newName, double newHours,
			      double newSalary, double newBonus)
	{
		super(newName, newHours, newSalary);
		this._bonus = newBonus;
	}


	public double getBonus() {
		return _bonus;
	}

	public void setBonus(double _bonus) {
		this._bonus = _bonus;
	}

	@Override
	public double calculatePay()
	{
		// call the super class instance of
		// the super class
		return super.calculatePay()+this._bonus;
	}

	@Override
	public String toString()
	{
		return super.toString() +", " +this._bonus;
	}


}
