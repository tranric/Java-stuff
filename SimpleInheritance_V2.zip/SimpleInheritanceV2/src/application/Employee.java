package application;

public class Employee
{
	// FIELDS
	protected String _name;
	protected double _hours;
	protected double _hourlySalary;

	// CONSTRUCTOR
	public Employee(String newName, double newHours, double newSalary)
	{
		this._name = newName;
		this._hours = newHours;
		this._hourlySalary = newSalary;

	}


	// OTHER METHODS
	// GETTERS AND SETTERS
	public String getName() {
		return _name;
	}
	public void setName(String _name) {
		this._name = _name;
	}
	public double getHours() {
		return _hours;
	}
	public void setHours(double _hours) {
		this._hours = _hours;
	}
	public double getHourlySalary() {
		return _hourlySalary;
	}
	public void setHourlySalary(double _hourlySalary) {
		this._hourlySalary = _hourlySalary;
	}

	public double calculatePay()
	{
		return this._hours * this._hourlySalary;
	}

	@Override
    public String toString()
    {
    	return this._name +", " + this._hourlySalary +", "+ this._hours;
    }



}
