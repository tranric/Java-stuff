package application;

public class Ceo extends Manager {

	// FIELDS
	private double _stockPrice;
	private int _numOfSharesSold;

	public Ceo(String newName, double newHours,
		      double newSalary, double newBonus, double newPrice, int newShares)
{
	super(newName, newHours, newSalary, newBonus);
	_stockPrice = newPrice;
	_numOfSharesSold = newShares;
}

	// METHODS
	// Getters and Setters

	public double getStockPrice() {
		return _stockPrice;
	}
	public void setStockPrice(double _stockPrice) {
		this._stockPrice = _stockPrice;
	}
	public int getNumOfSharesSold() {
		return _numOfSharesSold;
	}
	public void setNumOfSharesSold(int _numOfSharesSold) {
		this._numOfSharesSold = _numOfSharesSold;
	}

	// overriden method

	@Override
	public double calculatePay()
	{
		return super.calculatePay() +
			   (this._numOfSharesSold *this._stockPrice);

	}

}
