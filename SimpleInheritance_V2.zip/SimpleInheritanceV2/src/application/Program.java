package application;

public class Program {

	public static void main(String[] args)
	{
		// Declarations & initializations
		Employee emp = new Employee("John Smith", 40, 40.00);
		Manager man = new Manager("",0,0,0);
		Ceo ceo = new Ceo("",0,0,0,0,0);
		// Set the values
		// employee
		emp.setName("John Smith");
		emp.setHourlySalary(40.00);
		emp.setHours(40);

		// manager
		man.setName("Harry Potter");
		man.setHourlySalary(56.00);
		man.setHours(40);
		man.setBonus(500);

		// ceo
		ceo.setName("Kai Gholbegi");
		ceo.setHourlySalary(85.00);
		ceo.setHours(40);
		ceo.setBonus(1000);
		ceo.setNumOfSharesSold(100);
		ceo.setStockPrice(780.00);

       System.out.printf("Employee:\t$%-5.2f\n", emp.calculatePay());
       System.out.printf("Manager:\t$%-5.2f\n", man.calculatePay());
       System.out.printf("Ceo:\t$%-5.2f\n", ceo.calculatePay());

       // Test toString method
       System.out.println("Employee: "+ emp);
       System.out.println("Manager: " + man);
       System.out.println("Ceo: " + ceo);


	}


}
