package application;

public class Program {

	public static void main(String[] args)
	{
		// Declarations & initializations
		Employee emp = new Employee();
		Manager man = new Manager();

		// Set the values
		// employee
		emp.setName("John Smith");
		emp.setHourlySalary(40.00);
		emp.setHours(40);

		// manager
		man.setName("Harry Potter");
		man.setHourlySalary(56.00);
		man.setHours(40);
		man.setBonus(500);

       System.out.printf("Employee:\t$%-5.2f\n", emp.calculatePay());

       System.out.printf("Manager:\t$%-5.2f\n", man.calculatePay());


	}


}
